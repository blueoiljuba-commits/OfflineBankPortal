import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  UserPlus, 
  ArrowRightLeft, 
  TrendingUp, 
  History, 
  LogOut,
  Eye,
  EyeOff,
  Landmark,
  PiggyBank,
  Wallet
} from 'lucide-react';
import { getAccount, formatCurrency, getActiveFDTotal, getActiveRDTotal } from '@/lib/bankingStorage';
import idfcLogo from '@assets/Logo_of_IDFC_First_Bank.svg_1764143706443.png';
import { useEffect, useState } from 'react';

interface DashboardPageProps {
  onNavigate: (page: 'add-payee' | 'transfer' | 'fd-rd' | 'transactions') => void;
  onLogout: () => void;
}

export default function DashboardPage({ onNavigate, onLogout }: DashboardPageProps) {
  const [account, setAccount] = useState(getAccount());
  const [showDetails, setShowDetails] = useState(false);
  const [fdTotal, setFdTotal] = useState(0);
  const [rdTotal, setRdTotal] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setAccount(getAccount());
      setFdTotal(getActiveFDTotal());
      setRdTotal(getActiveRDTotal());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    setFdTotal(getActiveFDTotal());
    setRdTotal(getActiveRDTotal());
  }, []);

  if (!account) return null;

  const maskValue = (value: string) => {
    if (showDetails) return value;
    return value.replace(/./g, '•');
  };

  const totalBalance = account.balance + fdTotal + rdTotal;

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b border-card-border">
        <div className="max-w-6xl mx-auto px-3 sm:px-4 py-3 sm:py-4 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <img src={idfcLogo} alt="IDFC FIRST Bank" className="h-8 sm:h-10 w-auto flex-shrink-0" />
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-semibold truncate">{account.bankName}</h1>
              <p className="text-xs sm:text-sm text-muted-foreground truncate">Welcome, {showDetails ? account.accountHolder : maskValue(account.accountHolder)}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onLogout}
            data-testid="button-logout"
            className="flex-shrink-0"
          >
            <LogOut className="w-4 h-4 sm:mr-2" />
            <span className="hidden sm:inline">Logout</span>
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-3 sm:px-4 py-4 sm:py-6 space-y-4 sm:space-y-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2 sm:pb-4">
            <CardTitle className="text-base sm:text-lg">Account Information</CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowDetails(!showDetails)}
              data-testid="button-toggle-details"
              className="flex-shrink-0"
            >
              {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3 sm:gap-4">
              <div className="col-span-2 sm:col-span-1">
                <p className="text-xs sm:text-sm text-muted-foreground">Account Holder</p>
                <p className="text-sm sm:text-base font-medium" data-testid="text-account-holder">
                  {showDetails ? account.accountHolder : maskValue(account.accountHolder)}
                </p>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <p className="text-xs sm:text-sm text-muted-foreground">Account Number</p>
                <p className="text-sm sm:text-base font-mono font-medium" data-testid="text-account-number">
                  {showDetails ? account.accountNumber : maskValue(account.accountNumber)}
                </p>
              </div>
              <div>
                <p className="text-xs sm:text-sm text-muted-foreground">IFSC Code</p>
                <p className="text-sm sm:text-base font-mono" data-testid="text-ifsc">
                  {showDetails ? account.ifsc : maskValue(account.ifsc)}
                </p>
              </div>
              <div>
                <p className="text-xs sm:text-sm text-muted-foreground">MICR Code</p>
                <p className="text-sm sm:text-base font-mono" data-testid="text-micr">
                  {showDetails ? account.micr : maskValue(account.micr)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2 sm:pb-4">
            <CardTitle className="text-base sm:text-lg">Balance Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className={`grid gap-3 sm:gap-4 ${fdTotal > 0 || rdTotal > 0 ? 'grid-cols-1 sm:grid-cols-3' : 'grid-cols-1'}`}>
              <div className="flex items-center gap-3 p-3 sm:p-4 rounded-lg bg-muted/50">
                <div className="p-2 rounded-full bg-primary/10">
                  <Wallet className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs sm:text-sm text-muted-foreground">Account Balance</p>
                  <p className="text-base sm:text-lg font-semibold truncate" data-testid="text-balance">
                    {formatCurrency(account.balance)}
                  </p>
                </div>
              </div>
              {fdTotal > 0 && (
                <div className="flex items-center gap-3 p-3 sm:p-4 rounded-lg bg-muted/50">
                  <div className="p-2 rounded-full bg-green-500/10">
                    <Landmark className="w-4 h-4 sm:w-5 sm:h-5 text-green-600" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs sm:text-sm text-muted-foreground">Fixed Deposits</p>
                    <p className="text-base sm:text-lg font-semibold truncate" data-testid="text-fd-balance">
                      {formatCurrency(fdTotal)}
                    </p>
                  </div>
                </div>
              )}
              {rdTotal > 0 && (
                <div className="flex items-center gap-3 p-3 sm:p-4 rounded-lg bg-muted/50">
                  <div className="p-2 rounded-full bg-blue-500/10">
                    <PiggyBank className="w-4 h-4 sm:w-5 sm:h-5 text-blue-600" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs sm:text-sm text-muted-foreground">Recurring Deposits</p>
                    <p className="text-base sm:text-lg font-semibold truncate" data-testid="text-rd-balance">
                      {formatCurrency(rdTotal)}
                    </p>
                  </div>
                </div>
              )}
            </div>
            <div className="pt-3 sm:pt-4 border-t border-card-border">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 sm:gap-4">
                <p className="text-sm sm:text-base text-muted-foreground">Total Portfolio Value</p>
                <p className="text-2xl sm:text-3xl md:text-4xl font-bold text-primary" data-testid="text-total-balance">
                  {formatCurrency(totalBalance)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <Card className="hover-elevate cursor-pointer" onClick={() => onNavigate('add-payee')} data-testid="card-add-payee">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 p-3 sm:p-6 pb-2">
              <CardTitle className="text-sm sm:text-base font-medium">Add Payee</CardTitle>
              <UserPlus className="w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground flex-shrink-0" />
            </CardHeader>
            <CardContent className="p-3 sm:p-6 pt-0 sm:pt-0">
              <CardDescription className="text-xs sm:text-sm">
                Add new beneficiaries
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="hover-elevate cursor-pointer" onClick={() => onNavigate('transfer')} data-testid="card-transfer">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 p-3 sm:p-6 pb-2">
              <CardTitle className="text-sm sm:text-base font-medium">Transfer</CardTitle>
              <ArrowRightLeft className="w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground flex-shrink-0" />
            </CardHeader>
            <CardContent className="p-3 sm:p-6 pt-0 sm:pt-0">
              <CardDescription className="text-xs sm:text-sm">
                Send or add money
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="hover-elevate cursor-pointer" onClick={() => onNavigate('fd-rd')} data-testid="card-fd-rd">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 p-3 sm:p-6 pb-2">
              <CardTitle className="text-sm sm:text-base font-medium">FD / RD</CardTitle>
              <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground flex-shrink-0" />
            </CardHeader>
            <CardContent className="p-3 sm:p-6 pt-0 sm:pt-0">
              <CardDescription className="text-xs sm:text-sm">
                Manage deposits
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="hover-elevate cursor-pointer" onClick={() => onNavigate('transactions')} data-testid="card-transactions">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 p-3 sm:p-6 pb-2">
              <CardTitle className="text-sm sm:text-base font-medium">Transactions</CardTitle>
              <History className="w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground flex-shrink-0" />
            </CardHeader>
            <CardContent className="p-3 sm:p-6 pt-0 sm:pt-0">
              <CardDescription className="text-xs sm:text-sm">
                View history
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
