import FDRDPage from '../FDRDPage';
import { initializeDefaultData } from '@/lib/bankingStorage';

initializeDefaultData();

export default function FDRDPageExample() {
  return (
    <FDRDPage onBack={() => console.log('Back clicked')} />
  );
}
