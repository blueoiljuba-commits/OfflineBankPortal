import TransactionsPage from '../TransactionsPage';
import { initializeDefaultData } from '@/lib/bankingStorage';

initializeDefaultData();

export default function TransactionsPageExample() {
  return (
    <TransactionsPage onBack={() => console.log('Back clicked')} />
  );
}
