import TransferMoneyPage from '../TransferMoneyPage';
import { initializeDefaultData } from '@/lib/bankingStorage';

initializeDefaultData();

export default function TransferMoneyPageExample() {
  return (
    <TransferMoneyPage onBack={() => console.log('Back clicked')} />
  );
}
