import AddPayeePage from '../AddPayeePage';
import { initializeDefaultData } from '@/lib/bankingStorage';

initializeDefaultData();

export default function AddPayeePageExample() {
  return (
    <AddPayeePage onBack={() => console.log('Back clicked')} />
  );
}
