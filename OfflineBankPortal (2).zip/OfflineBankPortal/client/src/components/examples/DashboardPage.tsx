import DashboardPage from '../DashboardPage';
import { initializeDefaultData } from '@/lib/bankingStorage';

initializeDefaultData();

export default function DashboardPageExample() {
  return (
    <DashboardPage 
      onNavigate={(page) => console.log('Navigate to:', page)}
      onLogout={() => console.log('Logout clicked')}
    />
  );
}
