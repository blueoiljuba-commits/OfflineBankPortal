import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, ArrowRightLeft, Plus } from 'lucide-react';
import { 
  getPayees, 
  getAccount, 
  updateAccountBalance, 
  addTransaction,
  formatCurrency,
  type Payee 
} from '@/lib/bankingStorage';
import { useToast } from '@/hooks/use-toast';
import PINVerificationDialog from './PINVerificationDialog';

interface TransferMoneyPageProps {
  onBack: () => void;
}

export default function TransferMoneyPage({ onBack }: TransferMoneyPageProps) {
  const [payees] = useState<Payee[]>(getPayees());
  const [selectedPayee, setSelectedPayee] = useState('');
  const [debitAmount, setDebitAmount] = useState('');
  const [creditAmount, setCreditAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPINDialog, setShowPINDialog] = useState(false);
  const [creditPending, setCreditPending] = useState(false);
  const [debitPending, setDebitPending] = useState(false);
  const { toast } = useToast();

  const account = getAccount();

  const handleDebit = (e: React.FormEvent) => {
    e.preventDefault();
    setDebitPending(true);
    setShowPINDialog(true);
  };

  const executeDebit = () => {
    if (!account || !selectedPayee) return;

    const amount = parseFloat(debitAmount);
    if (amount > account.balance) {
      toast({
        title: 'Insufficient Balance',
        description: 'You do not have enough balance for this transfer.',
        variant: 'destructive',
      });
      return;
    }

    setIsProcessing(true);
    setTimeout(() => {
      const newBalance = account.balance - amount;
      updateAccountBalance(newBalance);
      
      const payee = payees.find(p => p.id === selectedPayee);
      const transaction = addTransaction({
        type: 'debit',
        amount,
        balanceAfter: newBalance,
        description: `Transfer to ${payee?.name}`,
        payeeName: payee?.name,
      });

      toast({
        title: 'Transfer Successful',
        description: (
          <div className="space-y-1">
            <p>Transaction ID: {transaction.id}</p>
            <p>Amount: {formatCurrency(amount)}</p>
            <p>New Balance: {formatCurrency(newBalance)}</p>
          </div>
        ),
      });

      setDebitAmount('');
      setSelectedPayee('');
      setIsProcessing(false);
    }, 1000);
  };

  const handleCredit = (e: React.FormEvent) => {
    e.preventDefault();
    setCreditPending(true);
    setShowPINDialog(true);
  };

  const executeCredit = () => {
    if (!account) return;

    const amount = parseFloat(creditAmount);
    setIsProcessing(true);

    setTimeout(() => {
      const newBalance = account.balance + amount;
      updateAccountBalance(newBalance);
      
      const transaction = addTransaction({
        type: 'credit',
        amount,
        balanceAfter: newBalance,
        description: 'Amount credited to account',
      });

      toast({
        title: 'Credit Successful',
        description: (
          <div className="space-y-1">
            <p>Transaction ID: {transaction.id}</p>
            <p>Amount: {formatCurrency(amount)}</p>
            <p>New Balance: {formatCurrency(newBalance)}</p>
          </div>
        ),
      });

      setCreditAmount('');
      setIsProcessing(false);
    }, 1000);
  };

  const handlePINVerify = (success: boolean) => {
    if (success) {
      if (creditPending) {
        executeCredit();
      } else if (debitPending) {
        executeDebit();
      }
    } else {
      toast({
        title: 'Wrong PIN',
        description: 'Incorrect PIN entered. Transaction cancelled.',
        variant: 'destructive',
      });
    }
    setShowPINDialog(false);
    setCreditPending(false);
    setDebitPending(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b border-card-border">
        <div className="max-w-4xl mx-auto px-3 sm:px-4 py-3 sm:py-4 flex items-center gap-2 sm:gap-3">
          <Button variant="ghost" size="icon" onClick={onBack} data-testid="button-back">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-base sm:text-lg font-semibold">Transfer Money</h1>
            <p className="text-xs sm:text-sm text-muted-foreground">Send or receive funds</p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-3 sm:px-4 py-4 sm:py-6">
        {account && (
          <Card className="mb-4 sm:mb-6">
            <CardContent className="p-4 sm:pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs sm:text-sm text-muted-foreground">Available Balance</p>
                  <p className="text-xl sm:text-2xl font-bold text-primary" data-testid="text-available-balance">
                    {formatCurrency(account.balance)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="debit" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="debit" data-testid="tab-debit" className="text-xs sm:text-sm">
              <ArrowRightLeft className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              <span className="hidden xs:inline">Debit</span> (Send)
            </TabsTrigger>
            <TabsTrigger value="credit" data-testid="tab-credit" className="text-xs sm:text-sm">
              <Plus className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              <span className="hidden xs:inline">Credit</span> (Receive)
            </TabsTrigger>
          </TabsList>

          <TabsContent value="debit">
            <Card>
              <CardHeader className="p-4 sm:p-6">
                <CardTitle className="text-base sm:text-lg">Send Money</CardTitle>
                <CardDescription className="text-xs sm:text-sm">Transfer funds to a saved payee</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
                <form onSubmit={handleDebit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="payee-select" className="text-sm">Select Payee</Label>
                    <Select value={selectedPayee} onValueChange={setSelectedPayee} required>
                      <SelectTrigger id="payee-select" data-testid="select-payee">
                        <SelectValue placeholder="Choose a payee" />
                      </SelectTrigger>
                      <SelectContent>
                        {payees.length === 0 ? (
                          <SelectItem value="none" disabled>No payees added</SelectItem>
                        ) : (
                          payees.map((payee) => (
                            <SelectItem key={payee.id} value={payee.id}>
                              {payee.name} - {payee.accountNumber}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="debit-amount" className="text-sm">Amount</Label>
                    <Input
                      id="debit-amount"
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={debitAmount}
                      onChange={(e) => setDebitAmount(e.target.value)}
                      placeholder="Enter amount"
                      className="font-mono"
                      data-testid="input-debit-amount"
                      required
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={!selectedPayee || !debitAmount || isProcessing || payees.length === 0}
                    data-testid="button-send-money"
                  >
                    {isProcessing ? 'Processing...' : 'Send Money'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="credit">
            <Card>
              <CardHeader className="p-4 sm:p-6">
                <CardTitle className="text-base sm:text-lg">Add Credit</CardTitle>
                <CardDescription className="text-xs sm:text-sm">Manually add funds to your account (for testing)</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
                <form onSubmit={handleCredit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="credit-amount" className="text-sm">Amount</Label>
                    <Input
                      id="credit-amount"
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={creditAmount}
                      onChange={(e) => setCreditAmount(e.target.value)}
                      placeholder="Enter amount to credit"
                      className="font-mono"
                      data-testid="input-credit-amount"
                      required
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={!creditAmount || isProcessing}
                    data-testid="button-add-credit"
                  >
                    {isProcessing ? 'Processing...' : 'Add Credit'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <PINVerificationDialog
          isOpen={showPINDialog}
          title="Verify PIN"
          description="Enter your 4-digit PIN to confirm this transaction"
          onVerify={handlePINVerify}
          onCancel={() => {
            setShowPINDialog(false);
            setCreditPending(false);
          }}
        />
      </main>
    </div>
  );
}
