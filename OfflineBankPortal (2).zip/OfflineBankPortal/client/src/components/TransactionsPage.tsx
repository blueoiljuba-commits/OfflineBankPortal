import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, ArrowDownLeft, ArrowUpRight, PiggyBank } from 'lucide-react';
import { getTransactions, formatCurrency, formatDate, type Transaction } from '@/lib/bankingStorage';

interface TransactionsPageProps {
  onBack: () => void;
}

const transactionIcons: Record<Transaction['type'], React.ReactNode> = {
  debit: <ArrowUpRight className="w-4 h-4 text-destructive" />,
  credit: <ArrowDownLeft className="w-4 h-4 text-green-600" />,
  fd_created: <PiggyBank className="w-4 h-4 text-primary" />,
  fd_withdrawn: <PiggyBank className="w-4 h-4 text-green-600" />,
  rd_created: <PiggyBank className="w-4 h-4 text-primary" />,
  rd_withdrawn: <PiggyBank className="w-4 h-4 text-green-600" />,
};

const transactionLabels: Record<Transaction['type'], string> = {
  debit: 'Debit',
  credit: 'Credit',
  fd_created: 'FD Created',
  fd_withdrawn: 'FD Withdrawn',
  rd_created: 'RD Created',
  rd_withdrawn: 'RD Withdrawn',
};

const transactionVariants: Record<Transaction['type'], 'destructive' | 'default' | 'secondary'> = {
  debit: 'destructive',
  credit: 'default',
  fd_created: 'secondary',
  fd_withdrawn: 'default',
  rd_created: 'secondary',
  rd_withdrawn: 'default',
};

export default function TransactionsPage({ onBack }: TransactionsPageProps) {
  const [transactions] = useState<Transaction[]>(getTransactions());

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b border-card-border">
        <div className="max-w-4xl mx-auto px-3 sm:px-4 py-3 sm:py-4 flex items-center gap-2 sm:gap-3">
          <Button variant="ghost" size="icon" onClick={onBack} data-testid="button-back">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-base sm:text-lg font-semibold">Transaction History</h1>
            <p className="text-xs sm:text-sm text-muted-foreground">
              {transactions.length} {transactions.length === 1 ? 'transaction' : 'transactions'}
            </p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-3 sm:px-4 py-4 sm:py-6">
        {transactions.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground text-sm sm:text-base">No transactions yet</p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="text-base sm:text-lg">All Transactions</CardTitle>
              <CardDescription className="text-xs sm:text-sm">Complete history sorted by latest</CardDescription>
            </CardHeader>
            <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
              <div className="space-y-3">
                {transactions.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex flex-col sm:flex-row sm:items-start sm:justify-between p-3 sm:p-4 border border-card-border rounded-md hover-elevate gap-3"
                    data-testid={`card-transaction-${transaction.id}`}
                  >
                    <div className="flex gap-3 flex-1 min-w-0">
                      <div className="mt-0.5 sm:mt-1 flex-shrink-0">
                        {transactionIcons[transaction.type]}
                      </div>
                      <div className="space-y-1 flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant={transactionVariants[transaction.type]} className="text-xs">
                            {transactionLabels[transaction.type]}
                          </Badge>
                          {transaction.payeeName && (
                            <span className="text-xs sm:text-sm text-muted-foreground truncate">
                              to {transaction.payeeName}
                            </span>
                          )}
                        </div>
                        <p className="text-xs sm:text-sm text-muted-foreground truncate">
                          {transaction.description}
                        </p>
                        <p className="text-xs font-mono text-muted-foreground truncate">
                          ID: {transaction.id}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(transaction.date)}
                        </p>
                      </div>
                    </div>
                    <div className="text-left sm:text-right flex sm:flex-col justify-between items-center sm:items-end border-t sm:border-t-0 pt-2 sm:pt-0 flex-shrink-0">
                      <p 
                        className={`text-base sm:text-lg font-semibold ${
                          transaction.type === 'debit' ? 'text-destructive' : 'text-green-600'
                        }`}
                      >
                        {transaction.type === 'debit' ? '-' : '+'}
                        {formatCurrency(transaction.amount)}
                      </p>
                      <p className="text-xs text-muted-foreground sm:mt-1">
                        Balance: {formatCurrency(transaction.balanceAfter)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
