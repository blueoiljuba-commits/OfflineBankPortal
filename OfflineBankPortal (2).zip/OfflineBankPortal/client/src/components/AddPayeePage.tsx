import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, UserPlus } from 'lucide-react';
import { getPayees, addPayee, type Payee } from '@/lib/bankingStorage';
import { useToast } from '@/hooks/use-toast';

interface AddPayeePageProps {
  onBack: () => void;
}

export default function AddPayeePage({ onBack }: AddPayeePageProps) {
  const [payees, setPayees] = useState<Payee[]>(getPayees());
  const [name, setName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifsc, setIfsc] = useState('');
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newPayee = addPayee({ name, accountNumber, ifsc });
    setPayees(getPayees());
    
    toast({
      title: 'Payee Added',
      description: `${name} has been added successfully.`,
    });

    setName('');
    setAccountNumber('');
    setIfsc('');
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b border-card-border">
        <div className="max-w-4xl mx-auto px-3 sm:px-4 py-3 sm:py-4 flex items-center gap-2 sm:gap-3">
          <Button variant="ghost" size="icon" onClick={onBack} data-testid="button-back">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-base sm:text-lg font-semibold">Manage Payees</h1>
            <p className="text-xs sm:text-sm text-muted-foreground">Add and view beneficiaries</p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-3 sm:px-4 py-4 sm:py-6 space-y-4 sm:space-y-6">
        <Card>
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
              <UserPlus className="w-4 h-4 sm:w-5 sm:h-5" />
              Add New Payee
            </CardTitle>
            <CardDescription className="text-xs sm:text-sm">Enter payee details to add a new beneficiary</CardDescription>
          </CardHeader>
          <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="payee-name" className="text-sm">Payee Name</Label>
                <Input
                  id="payee-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter payee name"
                  data-testid="input-payee-name"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="account-number" className="text-sm">Account Number</Label>
                <Input
                  id="account-number"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder="Enter account number"
                  className="font-mono"
                  data-testid="input-account-number"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="ifsc" className="text-sm">IFSC Code</Label>
                <Input
                  id="ifsc"
                  value={ifsc}
                  onChange={(e) => setIfsc(e.target.value.toUpperCase())}
                  placeholder="Enter IFSC code"
                  className="font-mono"
                  data-testid="input-ifsc"
                  required
                />
              </div>

              <Button type="submit" className="w-full" data-testid="button-add-payee">
                Add Payee
              </Button>
            </form>
          </CardContent>
        </Card>

        {payees.length > 0 && (
          <Card>
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="text-base sm:text-lg">Saved Payees ({payees.length})</CardTitle>
              <CardDescription className="text-xs sm:text-sm">Your beneficiary list</CardDescription>
            </CardHeader>
            <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
              <div className="space-y-3">
                {payees.map((payee) => (
                  <div
                    key={payee.id}
                    className="flex items-center justify-between p-3 sm:p-4 border border-card-border rounded-md hover-elevate"
                    data-testid={`card-payee-${payee.id}`}
                  >
                    <div className="space-y-1 min-w-0">
                      <p className="font-medium text-sm sm:text-base truncate" data-testid={`text-payee-name-${payee.id}`}>{payee.name}</p>
                      <p className="text-xs sm:text-sm font-mono text-muted-foreground truncate">
                        {payee.accountNumber}
                      </p>
                      <p className="text-xs sm:text-sm font-mono text-muted-foreground">
                        {payee.ifsc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
