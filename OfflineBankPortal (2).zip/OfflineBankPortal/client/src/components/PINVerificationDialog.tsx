import { useState } from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Lock } from 'lucide-react';

interface PINVerificationDialogProps {
  isOpen: boolean;
  title: string;
  description: string;
  onVerify: (success: boolean) => void;
  onCancel: () => void;
}

export default function PINVerificationDialog({
  isOpen,
  title,
  description,
  onVerify,
  onCancel,
}: PINVerificationDialogProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const handleVerify = () => {
    if (pin === '0000') {
      onVerify(true);
      setPin('');
      setError('');
    } else {
      onVerify(false);
      setPin('');
      setError('');
    }
  };

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onCancel();
      setPin('');
      setError('');
    }
  };

  return (
    <AlertDialog open={isOpen} onOpenChange={handleOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Enter 4-Digit PIN</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter PIN"
                className="pl-10"
                data-testid="input-pin-verification"
                autoFocus
              />
            </div>
          </div>
          {error && (
            <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
              {error}
            </div>
          )}
        </div>
        <div className="flex gap-2">
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleVerify}
            disabled={pin.length !== 4}
            data-testid="button-verify-pin"
          >
            Verify
          </AlertDialogAction>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
}
