import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Banknote, CalendarDays, TrendingUp } from 'lucide-react';
import { 
  getFDs, 
  getRDs, 
  addFD, 
  addRD,
  withdrawFD,
  withdrawRD,
  getAccount,
  updateAccountBalance,
  addTransaction,
  formatCurrency,
  formatDate,
  type FD,
  type RD
} from '@/lib/bankingStorage';
import { useToast } from '@/hooks/use-toast';
import PINVerificationDialog from './PINVerificationDialog';

interface FDRDPageProps {
  onBack: () => void;
}

interface PendingAction {
  type: 'fd_create' | 'rd_create' | 'fd_withdraw' | 'rd_withdraw' | null;
  fd?: FD;
  rd?: RD;
}

export default function FDRDPage({ onBack }: FDRDPageProps) {
  const [fds, setFds] = useState<FD[]>(getFDs());
  const [rds, setRds] = useState<RD[]>(getRDs());
  const [fdAmount, setFdAmount] = useState('');
  const [fdTenure, setFdTenure] = useState('');
  const [rdAmount, setRdAmount] = useState('');
  const [rdTenure, setRdTenure] = useState('');
  const [showPINDialog, setShowPINDialog] = useState(false);
  const [pendingAction, setPendingAction] = useState<PendingAction>({ type: null });
  const { toast } = useToast();

  const handleCreateFD = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(fdAmount);
    setPendingAction({ type: 'fd_create' });
    setShowPINDialog(true);
  };

  const executeCreateFD = () => {
    const account = getAccount();
    if (!account) return;

    const amount = parseFloat(fdAmount);
    if (amount > account.balance) {
      toast({
        title: 'Insufficient Balance',
        description: 'You do not have enough balance to create this FD.',
        variant: 'destructive',
      });
      return;
    }

    const newBalance = account.balance - amount;
    updateAccountBalance(newBalance);
    
    const fd = addFD(amount, parseInt(fdTenure));
    addTransaction({
      type: 'fd_created',
      amount,
      balanceAfter: newBalance,
      description: `FD created for ${fdTenure} months`,
    });

    setFds(getFDs());
    toast({
      title: 'FD Created Successfully',
      description: `Fixed Deposit of ${formatCurrency(amount)} created for ${fdTenure} months.`,
    });

    setFdAmount('');
    setFdTenure('');
  };

  const handleCreateRD = (e: React.FormEvent) => {
    e.preventDefault();
    setPendingAction({ type: 'rd_create' });
    setShowPINDialog(true);
  };

  const executeCreateRD = () => {
    const account = getAccount();
    if (!account) return;

    const monthlyAmount = parseFloat(rdAmount);
    const tenure = parseInt(rdTenure);
    const totalAmount = monthlyAmount * tenure;

    if (totalAmount > account.balance) {
      toast({
        title: 'Insufficient Balance',
        description: 'You do not have enough balance to create this RD.',
        variant: 'destructive',
      });
      return;
    }

    const newBalance = account.balance - totalAmount;
    updateAccountBalance(newBalance);
    
    const rd = addRD(monthlyAmount, tenure);
    addTransaction({
      type: 'rd_created',
      amount: totalAmount,
      balanceAfter: newBalance,
      description: `RD created - ${formatCurrency(monthlyAmount)}/month for ${tenure} months`,
    });

    setRds(getRDs());
    toast({
      title: 'RD Created Successfully',
      description: `Recurring Deposit of ${formatCurrency(monthlyAmount)}/month for ${tenure} months.`,
    });

    setRdAmount('');
    setRdTenure('');
  };

  const handleWithdrawFD = (fd: FD) => {
    setPendingAction({ type: 'fd_withdraw', fd });
    setShowPINDialog(true);
  };

  const executeWithdrawFD = (fd: FD) => {
    const account = getAccount();
    if (!account) return;

    const newBalance = account.balance + fd.amount;
    updateAccountBalance(newBalance);
    withdrawFD(fd.id);
    
    addTransaction({
      type: 'fd_withdrawn',
      amount: fd.amount,
      balanceAfter: newBalance,
      description: `FD withdrawn`,
    });

    setFds(getFDs());
    toast({
      title: 'FD Withdrawn',
      description: `${formatCurrency(fd.amount)} credited to your account.`,
    });
  };

  const handleWithdrawRD = (rd: RD) => {
    setPendingAction({ type: 'rd_withdraw', rd });
    setShowPINDialog(true);
  };

  const executeWithdrawRD = (rd: RD) => {
    const account = getAccount();
    if (!account) return;

    const newBalance = account.balance + rd.totalDeposited;
    updateAccountBalance(newBalance);
    withdrawRD(rd.id);
    
    addTransaction({
      type: 'rd_withdrawn',
      amount: rd.totalDeposited,
      balanceAfter: newBalance,
      description: `RD withdrawn`,
    });

    setRds(getRDs());
    toast({
      title: 'RD Withdrawn',
      description: `${formatCurrency(rd.totalDeposited)} credited to your account.`,
    });
  };

  const handlePINVerify = (success: boolean) => {
    if (success) {
      if (pendingAction.type === 'fd_create') {
        executeCreateFD();
      } else if (pendingAction.type === 'rd_create') {
        executeCreateRD();
      } else if (pendingAction.type === 'fd_withdraw' && pendingAction.fd) {
        executeWithdrawFD(pendingAction.fd);
      } else if (pendingAction.type === 'rd_withdraw' && pendingAction.rd) {
        executeWithdrawRD(pendingAction.rd);
      }
    } else {
      toast({
        title: 'Wrong PIN',
        description: 'Incorrect PIN entered. Transaction cancelled.',
        variant: 'destructive',
      });
    }
    setShowPINDialog(false);
    setPendingAction({ type: null });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-card border-b border-card-border">
        <div className="max-w-6xl mx-auto px-3 sm:px-4 py-3 sm:py-4 flex items-center gap-2 sm:gap-3">
          <Button variant="ghost" size="icon" onClick={onBack} data-testid="button-back">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-base sm:text-lg font-semibold">Fixed & Recurring Deposits</h1>
            <p className="text-xs sm:text-sm text-muted-foreground">Manage your investments</p>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-3 sm:px-4 py-4 sm:py-6">
        <Tabs defaultValue="fd" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="fd" data-testid="tab-fd" className="text-xs sm:text-sm">
              <Banknote className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Fixed Deposit
            </TabsTrigger>
            <TabsTrigger value="rd" data-testid="tab-rd" className="text-xs sm:text-sm">
              <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              Recurring Deposit
            </TabsTrigger>
          </TabsList>

          <TabsContent value="fd" className="space-y-4 sm:space-y-6">
            <Card>
              <CardHeader className="p-4 sm:p-6">
                <CardTitle className="text-base sm:text-lg">Create New FD</CardTitle>
                <CardDescription className="text-xs sm:text-sm">Lock in a lump sum amount for a fixed period</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
                <form onSubmit={handleCreateFD} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fd-amount" className="text-sm">Amount</Label>
                      <Input
                        id="fd-amount"
                        type="number"
                        step="0.01"
                        min="1000"
                        value={fdAmount}
                        onChange={(e) => setFdAmount(e.target.value)}
                        placeholder="Minimum ₹1,000"
                        className="font-mono"
                        data-testid="input-fd-amount"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fd-tenure" className="text-sm">Tenure (Months)</Label>
                      <Input
                        id="fd-tenure"
                        type="number"
                        min="6"
                        max="120"
                        value={fdTenure}
                        onChange={(e) => setFdTenure(e.target.value)}
                        placeholder="6 to 120 months"
                        data-testid="input-fd-tenure"
                        required
                      />
                    </div>
                  </div>
                  <Button type="submit" className="w-full" data-testid="button-create-fd">
                    Create FD
                  </Button>
                </form>
              </CardContent>
            </Card>

            {fds.filter(fd => fd.status === 'active').length > 0 && (
              <Card>
                <CardHeader className="p-4 sm:p-6">
                  <CardTitle className="text-base sm:text-lg">Active Fixed Deposits</CardTitle>
                </CardHeader>
                <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {fds.filter(fd => fd.status === 'active').map((fd) => (
                      <Card key={fd.id} data-testid={`card-fd-${fd.id}`}>
                        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 p-3 sm:p-4 pb-2">
                          <CardTitle className="text-sm sm:text-base font-medium truncate">FD - {fd.id}</CardTitle>
                          <Badge variant="secondary" className="text-xs flex-shrink-0">Active</Badge>
                        </CardHeader>
                        <CardContent className="space-y-3 p-3 sm:p-4 pt-0">
                          <div>
                            <p className="text-xl sm:text-2xl font-bold text-primary">
                              {formatCurrency(fd.amount)}
                            </p>
                          </div>
                          <div className="space-y-1 text-xs sm:text-sm">
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <CalendarDays className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />
                              <span>Tenure: {fd.tenure} months</span>
                            </div>
                            <p className="text-muted-foreground">
                              Maturity: {formatDate(fd.maturityDate)}
                            </p>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="w-full"
                            onClick={() => handleWithdrawFD(fd)}
                            data-testid={`button-withdraw-fd-${fd.id}`}
                          >
                            Withdraw FD
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="rd" className="space-y-4 sm:space-y-6">
            <Card>
              <CardHeader className="p-4 sm:p-6">
                <CardTitle className="text-base sm:text-lg">Create New RD</CardTitle>
                <CardDescription className="text-xs sm:text-sm">Save a fixed amount every month</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
                <form onSubmit={handleCreateRD} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="rd-amount" className="text-sm">Monthly Amount</Label>
                      <Input
                        id="rd-amount"
                        type="number"
                        step="0.01"
                        min="500"
                        value={rdAmount}
                        onChange={(e) => setRdAmount(e.target.value)}
                        placeholder="Minimum ₹500/month"
                        className="font-mono"
                        data-testid="input-rd-amount"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="rd-tenure" className="text-sm">Tenure (Months)</Label>
                      <Input
                        id="rd-tenure"
                        type="number"
                        min="6"
                        max="120"
                        value={rdTenure}
                        onChange={(e) => setRdTenure(e.target.value)}
                        placeholder="6 to 120 months"
                        data-testid="input-rd-tenure"
                        required
                      />
                    </div>
                  </div>
                  {rdAmount && rdTenure && (
                    <div className="p-3 bg-muted rounded-md">
                      <p className="text-xs sm:text-sm text-muted-foreground">Total Deposit Amount</p>
                      <p className="text-base sm:text-lg font-semibold">
                        {formatCurrency(parseFloat(rdAmount) * parseInt(rdTenure))}
                      </p>
                    </div>
                  )}
                  <Button type="submit" className="w-full" data-testid="button-create-rd">
                    Create RD
                  </Button>
                </form>
              </CardContent>
            </Card>

            {rds.filter(rd => rd.status === 'active').length > 0 && (
              <Card>
                <CardHeader className="p-4 sm:p-6">
                  <CardTitle className="text-base sm:text-lg">Active Recurring Deposits</CardTitle>
                </CardHeader>
                <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {rds.filter(rd => rd.status === 'active').map((rd) => (
                      <Card key={rd.id} data-testid={`card-rd-${rd.id}`}>
                        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 p-3 sm:p-4 pb-2">
                          <CardTitle className="text-sm sm:text-base font-medium truncate">RD - {rd.id}</CardTitle>
                          <Badge variant="secondary" className="text-xs flex-shrink-0">Active</Badge>
                        </CardHeader>
                        <CardContent className="space-y-3 p-3 sm:p-4 pt-0">
                          <div>
                            <p className="text-xs sm:text-sm text-muted-foreground">Monthly Deposit</p>
                            <p className="text-lg sm:text-xl font-bold text-primary">
                              {formatCurrency(rd.monthlyAmount)}
                            </p>
                          </div>
                          <div className="space-y-1 text-xs sm:text-sm">
                            <p className="text-muted-foreground">
                              Tenure: {rd.tenure} months
                            </p>
                            <p className="text-muted-foreground">
                              Total: {formatCurrency(rd.totalDeposited)}
                            </p>
                            <p className="text-muted-foreground">
                              Maturity: {formatDate(rd.maturityDate)}
                            </p>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="w-full"
                            onClick={() => handleWithdrawRD(rd)}
                            data-testid={`button-withdraw-rd-${rd.id}`}
                          >
                            Withdraw RD
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        <PINVerificationDialog
          isOpen={showPINDialog}
          title="Verify PIN"
          description="Enter your 4-digit PIN to confirm this transaction"
          onVerify={handlePINVerify}
          onCancel={() => {
            setShowPINDialog(false);
            setPendingAction({ type: null });
          }}
        />
      </main>
    </div>
  );
}
