import { useState, useEffect } from 'react';
import { initializeDefaultData } from '@/lib/bankingStorage';
import LoginPage from '@/components/LoginPage';
import DashboardPage from '@/components/DashboardPage';
import AddPayeePage from '@/components/AddPayeePage';
import TransferMoneyPage from '@/components/TransferMoneyPage';
import FDRDPage from '@/components/FDRDPage';
import TransactionsPage from '@/components/TransactionsPage';

type Page = 'login' | 'dashboard' | 'add-payee' | 'transfer' | 'fd-rd' | 'transactions';

export default function Home() {
  const [currentPage, setCurrentPage] = useState<Page>('login');

  useEffect(() => {
    initializeDefaultData();
  }, []);

  const handleLogin = () => {
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setCurrentPage('login');
  };

  const handleNavigate = (page: 'add-payee' | 'transfer' | 'fd-rd' | 'transactions') => {
    setCurrentPage(page);
  };

  const handleBack = () => {
    setCurrentPage('dashboard');
  };

  switch (currentPage) {
    case 'login':
      return <LoginPage onLoginSuccess={handleLogin} />;
    case 'dashboard':
      return <DashboardPage onNavigate={handleNavigate} onLogout={handleLogout} />;
    case 'add-payee':
      return <AddPayeePage onBack={handleBack} />;
    case 'transfer':
      return <TransferMoneyPage onBack={handleBack} />;
    case 'fd-rd':
      return <FDRDPage onBack={handleBack} />;
    case 'transactions':
      return <TransactionsPage onBack={handleBack} />;
    default:
      return <LoginPage onLoginSuccess={handleLogin} />;
  }
}
