// Banking data storage utility using localStorage

export interface BankAccount {
  accountNumber: string;
  accountHolder: string;
  bankName: string;
  ifsc: string;
  micr: string;
  balance: number;
  pin: string;
}

export interface Payee {
  id: string;
  name: string;
  accountNumber: string;
  ifsc: string;
}

export interface Transaction {
  id: string;
  type: 'debit' | 'credit' | 'fd_created' | 'fd_withdrawn' | 'rd_created' | 'rd_withdrawn';
  amount: number;
  date: string;
  balanceAfter: number;
  description: string;
  payeeName?: string;
}

export interface FD {
  id: string;
  amount: number;
  tenure: number;
  createdDate: string;
  maturityDate: string;
  status: 'active' | 'withdrawn';
}

export interface RD {
  id: string;
  monthlyAmount: number;
  tenure: number;
  createdDate: string;
  maturityDate: string;
  totalDeposited: number;
  status: 'active' | 'withdrawn';
}

const STORAGE_KEYS = {
  ACCOUNT: 'localbank_account',
  PAYEES: 'localbank_payees',
  TRANSACTIONS: 'localbank_transactions',
  FDS: 'localbank_fds',
  RDS: 'localbank_rds',
  INITIALIZED: 'localbank_initialized',
};

// Initialize default account data
export function initializeDefaultData() {
  const initialized = localStorage.getItem(STORAGE_KEYS.INITIALIZED);
  
  if (!initialized) {
    const defaultAccount: BankAccount = {
      accountNumber: '10066531011',
      accountHolder: 'Danayal Ahmad',
      bankName: 'IDFC BANK',
      ifsc: 'IDFB0064914',
      micr: '110002345',
      balance: 5800000,
      pin: '8454',
    };
    
    localStorage.setItem(STORAGE_KEYS.ACCOUNT, JSON.stringify(defaultAccount));
    localStorage.setItem(STORAGE_KEYS.PAYEES, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.FDS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.RDS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
  } else {
    // Always update bank name and IFSC to latest values
    const account = getAccount();
    if (account && (account.bankName !== 'IDFC BANK' || account.ifsc !== 'IDFB0064914')) {
      account.bankName = 'IDFC BANK';
      account.ifsc = 'IDFB0064914';
      localStorage.setItem(STORAGE_KEYS.ACCOUNT, JSON.stringify(account));
    }
  }
}

export function getAccount(): BankAccount | null {
  const data = localStorage.getItem(STORAGE_KEYS.ACCOUNT);
  return data ? JSON.parse(data) : null;
}

export function updateAccountBalance(newBalance: number): void {
  const account = getAccount();
  if (account) {
    account.balance = newBalance;
    localStorage.setItem(STORAGE_KEYS.ACCOUNT, JSON.stringify(account));
  }
}

export function validatePin(pin: string): boolean {
  const account = getAccount();
  return account ? account.pin === pin : false;
}

export function getPayees(): Payee[] {
  const data = localStorage.getItem(STORAGE_KEYS.PAYEES);
  return data ? JSON.parse(data) : [];
}

export function addPayee(payee: Omit<Payee, 'id'>): Payee {
  const payees = getPayees();
  const newPayee: Payee = {
    ...payee,
    id: Date.now().toString(),
  };
  payees.push(newPayee);
  localStorage.setItem(STORAGE_KEYS.PAYEES, JSON.stringify(payees));
  return newPayee;
}

export function getTransactions(): Transaction[] {
  const data = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
  const transactions = data ? JSON.parse(data) : [];
  return transactions.sort((a: Transaction, b: Transaction) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );
}

export function addTransaction(transaction: Omit<Transaction, 'id' | 'date'>): Transaction {
  const transactions = getTransactions();
  const newTransaction: Transaction = {
    ...transaction,
    id: `TXN${Date.now()}`,
    date: new Date().toISOString(),
  };
  transactions.push(newTransaction);
  localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  return newTransaction;
}

export function getFDs(): FD[] {
  const data = localStorage.getItem(STORAGE_KEYS.FDS);
  return data ? JSON.parse(data) : [];
}

export function addFD(amount: number, tenure: number): FD {
  const fds = getFDs();
  const createdDate = new Date();
  const maturityDate = new Date(createdDate);
  maturityDate.setMonth(maturityDate.getMonth() + tenure);
  
  const newFD: FD = {
    id: `FD${Date.now()}`,
    amount,
    tenure,
    createdDate: createdDate.toISOString(),
    maturityDate: maturityDate.toISOString(),
    status: 'active',
  };
  
  fds.push(newFD);
  localStorage.setItem(STORAGE_KEYS.FDS, JSON.stringify(fds));
  return newFD;
}

export function withdrawFD(id: string): void {
  const fds = getFDs();
  const fd = fds.find(f => f.id === id);
  if (fd) {
    fd.status = 'withdrawn';
    localStorage.setItem(STORAGE_KEYS.FDS, JSON.stringify(fds));
  }
}

export function getRDs(): RD[] {
  const data = localStorage.getItem(STORAGE_KEYS.RDS);
  return data ? JSON.parse(data) : [];
}

export function addRD(monthlyAmount: number, tenure: number): RD {
  const rds = getRDs();
  const createdDate = new Date();
  const maturityDate = new Date(createdDate);
  maturityDate.setMonth(maturityDate.getMonth() + tenure);
  
  const newRD: RD = {
    id: `RD${Date.now()}`,
    monthlyAmount,
    tenure,
    createdDate: createdDate.toISOString(),
    maturityDate: maturityDate.toISOString(),
    totalDeposited: monthlyAmount * tenure,
    status: 'active',
  };
  
  rds.push(newRD);
  localStorage.setItem(STORAGE_KEYS.RDS, JSON.stringify(rds));
  return newRD;
}

export function withdrawRD(id: string): void {
  const rds = getRDs();
  const rd = rds.find(r => r.id === id);
  if (rd) {
    rd.status = 'withdrawn';
    localStorage.setItem(STORAGE_KEYS.RDS, JSON.stringify(rds));
  }
}

export function formatCurrency(amount: number): string {
  return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function getActiveFDTotal(): number {
  const fds = getFDs();
  return fds
    .filter(fd => fd.status === 'active')
    .reduce((total, fd) => total + fd.amount, 0);
}

export function getActiveRDTotal(): number {
  const rds = getRDs();
  return rds
    .filter(rd => rd.status === 'active')
    .reduce((total, rd) => total + rd.totalDeposited, 0);
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-IN', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}
