# Offline Banking System - IDFC BANK

## Overview

This is a fully functional offline banking simulation built as a single-page application. The system operates entirely in the browser using localStorage for data persistence, requiring no backend infrastructure. It simulates core banking operations including account management, payee management, money transfers, and fixed/recurring deposits.

The application is designed for a single predefined account holder (Danayal Ahmad) with preset credentials and starting balance, providing a complete banking experience without any server-side dependencies.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework Stack:**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server
- **Wouter** for lightweight client-side routing
- **TanStack Query** for state management (though not actively used given the localStorage approach)

**UI Component System:**
- **shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom design tokens
- **Material Design-inspired** visual language optimized for banking trust and clarity
- Components follow the "New York" style variant with customized banking-specific color schemes

**Design Principles:**
- Typography hierarchy using Inter/Roboto fonts for readability
- Monospace fonts for account numbers and financial data
- Consistent spacing system based on Tailwind units (2, 4, 6, 8)
- Card-based layout with clear visual hierarchy
- Responsive design with mobile-first breakpoints

### Data Storage Architecture

**Client-Side Persistence:**
- All data stored in browser **localStorage** (no database, no backend)
- Storage keys namespaced with `localbank_` prefix
- Data structures defined in TypeScript interfaces for type safety

**Data Models:**
```typescript
- BankAccount: Core account information (holder, number, IFSC, MICR, balance, PIN)
- Payee: Beneficiary details for transfers
- Transaction: History of all banking operations
- FD: Fixed deposit records with maturity tracking
- RD: Recurring deposit records with monthly tracking
```

**Storage Strategy:**
- Initialization function seeds default data on first load
- Real-time balance updates across all views
- Transaction logging for audit trail
- Atomic updates to prevent data corruption

### Application Structure

**Page-Based Navigation:**
- Single root component (`Home`) manages routing state
- Page components are isolated and receive navigation callbacks
- No URL-based routing; all navigation via state management

**Core Pages:**
1. **LoginPage**: PIN authentication (hardcoded: 8454)
2. **DashboardPage**: Account overview with quick actions
3. **AddPayeePage**: Beneficiary management
4. **TransferMoneyPage**: Debit/credit money transfers
5. **FDRDPage**: Fixed and recurring deposit management
6. **TransactionsPage**: Complete transaction history

**State Management Pattern:**
- No global state library required
- localStorage acts as single source of truth
- Components read/write directly to storage utility functions
- Real-time polling for balance updates (1-second interval on dashboard)

### Authentication

**Security Model:**
- Simple PIN-based authentication (hardcoded for demo)
- No session management or token-based auth
- Login state not persisted (resets on page refresh)
- Logout returns to login page without clearing data

### Transaction Processing

**Debit Flow:**
1. Validate sufficient balance
2. Deduct amount from account
3. Generate unique transaction ID
4. Log transaction with timestamp
5. Update balance in localStorage
6. Show confirmation with new balance

**Credit Flow:**
1. Add amount to account balance
2. Generate transaction record
3. Update localStorage
4. Display updated balance

**FD/RD Management:**
- Calculate maturity dates based on tenure
- Track deposit status (active/withdrawn)
- Auto-deduct from balance on creation
- Credit back with interest on withdrawal
- Interest calculation: 7% annually for FD, 8% for RD

### Build and Development

**Development Mode:**
- Vite dev server with HMR
- Express server serves Vite middleware
- Custom error overlays via Replit plugins
- Source maps enabled for debugging

**Production Build:**
- Vite bundles client code
- esbuild bundles Express server
- Static file serving from `dist/public`
- Single deployment artifact

**Path Aliases:**
- `@/` → `client/src/`
- `@shared/` → `shared/`
- `@assets/` → `attached_assets/`

### UI Component Library

**Custom Components:**
- Form inputs with validation styling
- Card layouts for information display
- Modal dialogs for confirmations
- Toast notifications for user feedback
- Tab interfaces for FD/RD sections
- Select dropdowns for payee selection
- Badge components for transaction types

**Accessibility:**
- Semantic HTML structure
- ARIA labels on interactive elements
- Keyboard navigation support
- Focus management in forms

## External Dependencies

### Third-Party Libraries

**UI and Styling:**
- `@radix-ui/*`: Unstyled, accessible component primitives (accordion, dialog, dropdown, etc.)
- `tailwindcss`: Utility-first CSS framework
- `class-variance-authority`: Type-safe component variants
- `lucide-react`: Icon library for UI elements

**React Ecosystem:**
- `react` & `react-dom`: Core framework
- `wouter`: Lightweight routing
- `@tanstack/react-query`: Data fetching (minimal usage)
- `react-hook-form` with `@hookform/resolvers`: Form management
- `zod`: Schema validation

**Development Tools:**
- `vite`: Build tool and dev server
- `typescript`: Type checking
- `@vitejs/plugin-react`: React integration for Vite
- `@replit/vite-plugin-*`: Replit-specific dev tools

**Date/Time:**
- `date-fns`: Date formatting and manipulation

**Database (Configured but Not Used):**
- `@neondatabase/serverless`: PostgreSQL driver
- `drizzle-orm` & `drizzle-kit`: ORM and migrations
- Note: Database configuration present but application uses localStorage only

### External Services

**Fonts:**
- Google Fonts CDN for Inter, Roboto, Architects Daughter, DM Sans, Fira Code, and Geist Mono

**Assets:**
- IDFC FIRST Bank logo (stored in attached_assets/)

### Infrastructure

**Runtime Environment:**
- Node.js for build and development server
- Browser localStorage API for data persistence
- No external APIs or webhooks
- No authentication services
- No email/SMS services

**Session Management:**
- `express-session` with `connect-pg-simple` (configured but unused)
- Sessions not persisted across page reloads in current implementation