# Design Guidelines: Local Bank Offline Banking System

## Design Approach
**Selected System**: Material Design-inspired approach with banking industry conventions
**Rationale**: Banking applications require trust, clarity, and efficient information processing. Users expect familiar patterns that emphasize security and data accuracy.

## Typography System
- **Primary Font**: Inter or Roboto via Google Fonts CDN
- **Headings**: 
  - H1 (Account holder name, page titles): text-2xl md:text-3xl, font-semibold
  - H2 (Section headers): text-xl md:text-2xl, font-medium
  - H3 (Card titles, labels): text-lg, font-medium
- **Body Text**: text-base, font-normal
- **Account Numbers/Amounts**: text-base md:text-lg, font-mono for clarity
- **Balance Display**: text-3xl md:text-4xl, font-bold (prominent)
- **Small Print** (IFSC, MICR codes): text-sm, font-normal

## Layout System
**Spacing Units**: Use Tailwind units of 2, 4, 6, and 8 consistently
- Component padding: p-4 or p-6
- Section margins: mb-6 or mb-8
- Card spacing: gap-4 between elements
- Form field spacing: space-y-4
- Button padding: px-6 py-3

**Container Strategy**:
- Max-width wrapper: max-w-6xl mx-auto px-4
- Dashboard cards: Grid layout with grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Forms: Single column, max-w-md mx-auto

## Component Library

### 1. Login Page
- Centered card layout with max-w-md
- Bank logo placeholder at top (<!-- LOGO: Local Bank emblem -->)
- PIN input field (numeric, password type)
- Full-width submit button
- Error message area below button
- Minimal, focused design with generous padding (p-8)

### 2. Navigation
- Top navigation bar: Sticky header with bank name left, logout button right
- Balance indicator in header (always visible)
- Mobile: Hamburger menu for navigation items

### 3. Dashboard Layout
**Account Information Card**:
- Prominent placement at top
- Display in 2-column grid for desktop: Name/Account Number | IFSC/MICR
- Balance: Large, bold, centered or right-aligned
- Bordered card with rounded corners (rounded-lg border-2)

**Action Buttons Grid**:
- 2x2 grid on desktop, stacked on mobile
- Each button as a card with icon (Heroicons CDN) + label
- Icons: Plus (Add Payee), ArrowRight (Transfer), ChartBar (FD/RD), Clock (Transactions)
- Equal height cards with hover elevation

### 4. Forms (Add Payee, Transfer, FD/RD)
**Structure**:
- Label above each input: text-sm font-medium mb-2
- Input fields: Full width, p-3, rounded-md border
- Dropdown for payee selection: Full width with chevron icon
- Amount inputs: Right-aligned text for numerical clarity
- Submit button: Full width, p-3, rounded-md
- Success/error messages: Fixed positioning or toast at top

**Form Groups**:
- Each field wrapped in div with mb-4
- Required field indicator: Asterisk in label
- Validation messages below inputs (text-sm)

### 5. Transaction History
**List Structure**:
- Card-based list, not table (better for mobile)
- Each transaction card contains:
  - Transaction type badge (top-left): Debit/Credit/FD Created/etc.
  - Amount (prominent, right-aligned)
  - Date/time (text-sm below type)
  - Transaction ID (text-xs, monospace)
  - Balance after transaction (subtle, bottom)
- Stack on mobile, can use 2-column on larger screens
- Dividers between items (border-b)

### 6. FD/RD Cards
- Display as cards in grid layout
- Each card shows:
  - Type (FD/RD) as header
  - Amount invested (large text)
  - Tenure and maturity date
  - Withdraw button (secondary style)
- Use icons for visual differentiation (Heroicons: Banknotes, Clock)

### 7. Payee List
- Simple list with edit/delete actions
- Name (bold), Account Number (monospace), IFSC (smaller text)
- Action icons on right (Edit, Delete)
- Add New button at bottom

## Animations
**Minimal Use Only**:
- Button hover: Subtle background transition (200ms ease)
- Card hover: Slight elevation change (shadow transition)
- Form submission: Loading spinner on button
- Modal/toast entry: Fade + slide (300ms)
- NO complex scroll animations or unnecessary motion

## Responsive Behavior
**Mobile (< 768px)**:
- Single column layout throughout
- Stack all grid items vertically
- Reduce padding: p-4 instead of p-6
- Smaller typography scales
- Bottom-fixed action buttons where appropriate (transfer, submit)
- Collapsible navigation

**Tablet (768px - 1024px)**:
- 2-column grids where applicable
- Moderate spacing
- Side-by-side forms with compact inputs

**Desktop (> 1024px)**:
- 3-column dashboard grid
- Maximum width container (max-w-6xl)
- Spacious layouts with generous whitespace

## Icons
**Library**: Heroicons (CDN)
**Usage**:
- Dashboard buttons: 24px icons with labels
- Form inputs: 20px icons (optional, for clarity)
- Transaction types: 16px inline icons
- Navigation: 24px in header
- Action buttons: 20px (edit, delete, etc.)

## Images
**No hero images required** - This is a functional banking application.
**Logo**: Simple placeholder for "Local Bank" logo in header and login page (<!-- LOGO PLACEHOLDER -->)

## Accessibility
- Proper label associations for all inputs
- Focus states: 2px outline offset
- Sufficient contrast for all text
- Keyboard navigation support
- Screen reader labels for icon-only buttons
- Error messages with aria-live regions